package constants;

public interface OS {
    final String ANDROID="Android";
    final String iOS="iOS";
}
