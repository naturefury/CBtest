package pages;

import base.Keywords;
import exceptions.ApplicationException;
import exceptions.EnvironmentException;
import org.openqa.selenium.By;
import xpath.Matching;

public class PageWelcome extends Keywords {

    String alreadyLoginEmail;

    private String keyBtnLogin="Getgo.Welcome.BtnLogin";
    private String keyBtnSignUp="Getgo.Welcome.BtnSignUp";

    public void launchGetgo() throws EnvironmentException {
	    launchApplication();
    }

    public void launchGetgoFresh() throws EnvironmentException {
        driver=null;
        launchApplication();
    }

    public void doesPageContains(String loginBtnTxt,String signUpBtnTxt,String captionTxt) throws ApplicationException
    {
	    verify.elementIsPresent("Getgo.Welcome.ImgLogo");
        verify.elementTextMatching("Getgo.Welcome.LblCaption",captionTxt);
        verify.elementTextMatching(keyBtnLogin,loginBtnTxt);
        verify.elementTextMatching(keyBtnSignUp,signUpBtnTxt);
    }

    public void clickLogin() throws ApplicationException {
        try {
            click.elementBy(keyBtnLogin);
        }
        catch (Exception e)
        {
            if(driver.findElementByAccessibilityId("ic_profile_landing").isDisplayed())
            {
                alreadyLoginEmail=get.elementText(By.xpath("(XCUIElementTypeStaticText)[2]"));

                click.elementBy(xpathOf.button(Matching.name("USE PASSWORD")));
            }

        }

    }

    public void clickSignUp() throws ApplicationException {
        click.elementBy(keyBtnSignUp);
    }


}
